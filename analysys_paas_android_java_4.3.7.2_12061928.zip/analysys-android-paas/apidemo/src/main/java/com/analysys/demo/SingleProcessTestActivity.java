package com.analysys.demo;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Description: 测试独立进程
 * Author: fengzeyuan
 * Date: 2019-11-20 16:34
 * Version: 1.0
 */
public class SingleProcessTestActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View view) {

    }
}
